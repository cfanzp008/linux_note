sudo python local.py -c /etc/shadowsocks/ssr.json -d stop
