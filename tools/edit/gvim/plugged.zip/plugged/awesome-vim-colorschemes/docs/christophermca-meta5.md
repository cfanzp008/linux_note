# meta5.vim
#####This dark colorscheme, inspired by Tron  
Designed for 256 color terminals and GUIs.
![](http://christophermca.github.io/img/meta5-screenshot.png "meta5-javascript")
![](http://christophermca.github.io/img/meta5-select.png "meta5-select")

## Install
Pathogen
```
git clone https://github.com/christophermca/meta5.git
```

Vundle
```
Plugin 'christophermca/meta5'
```
