# scheakur.vim

A light/dark colorscheme for Vim.

## Light

```vim
set background=light
colorscheme scheakur
```

http://vimcolors.com/252/scheakur/light

## Dark

```vim
set background=dark
colorscheme scheakur
```

http://vimcolors.com/252/scheakur/dark
