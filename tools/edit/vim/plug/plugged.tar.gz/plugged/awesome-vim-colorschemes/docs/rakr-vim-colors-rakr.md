= vim-colors-rakr
Flat colorscheme light and dark variant

== Screenshot
=== Dark

image::screenshots/dark.png[Dark]

=== Light

image::screenshots/light.png[Light]

