using System; class Program { static int Main(string[] args) { Console.WriteLine(args[0]); int i = 0; i++; return 0; } 
    public int Foo() { switch (1) { case 1: int i = 0; default: int j = 1; }
    }
}
