#!/bin/bash

git rev-parse --short HEAD > source_version
